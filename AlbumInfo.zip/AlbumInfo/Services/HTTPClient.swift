//
//  HTTPClient.swift
//  AlbumInfo
//
//  Created by William Howze on 9/24/23.
//

import Foundation

class ViewModel: ObservableObject {
    
    @Published var feed: [Result] = []
    
    
    func fetch() {
        // get the data
        guard let url = URL(string: "https://rss.applemarketingtools.com/api/v2/us/music/most-played/10/songs.json") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            // convert this data to JSON
            
            do {
                let decodedData = try JSONDecoder().decode(Welcome.self, from: data) // I wasn't Welcome, [Result]
                DispatchQueue.main.async {
                    self?.feed = decodedData.feed.results
                }
            } catch {
                print(error)
            }
        }
        
        task.resume()
    }
}
