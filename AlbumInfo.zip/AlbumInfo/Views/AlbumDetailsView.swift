//
//  AlbumDetailsView.swift
//  AlbumInfo
//
//  Created by William Howze on 9/24/23.
//

import SwiftUI

struct AlbumDetailsView: View {
    
    
    
    var body: some View {
        VStack {
            Text("Hello Detail View")
        }
    }
    
    
    
    
    
    
    
    struct AlbumDetailsView_Previews: PreviewProvider {
        static var previews: some View {
            AlbumDetailsView()
        }
    }
}
