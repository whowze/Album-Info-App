//
//  ContentView.swift
//  AlbumInfo
//  Added More Info - Delete this later
//  Created by Howze, Bill on 9/19/23.
//

import SwiftUI

struct AlbumInfoView: View {
    @StateObject var viewModel = ViewModel()

    var body: some View {
        NavigationView {
            List {
                VStack {
                    ForEach(viewModel.feed, id: \.self) { results in
                        NavigationLink(destination: AlbumDetailsView()) {
                            HStack {
                                Text(results.artistName)
                                //                            Text(results.songTitle)
                            }
                            .padding()
                        }
                    }
                }

                .navigationTitle("Song List")
                .onAppear {
                    viewModel.fetch()
                }
            }
        }
    }
}

struct AlbumInfoView_Previews: PreviewProvider {
    static var previews: some View {
        AlbumInfoView()
    }
}
